import React from 'react';

const Contact = () => {
  return <h1></h1>;
};

export default Contact;
